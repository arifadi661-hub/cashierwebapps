# Kasir F&B Web App

Web App/PWA offline. Bisa dibuka di browser desktop atau mobile dan dipasang ke layar utama seperti aplikasi.

## Menjalankan lokal

Service worker tidak aktif dari `file://`. Jalankan server lokal dari folder ini:

```bash
python -m http.server 8080
```

Buka `http://localhost:8080`.

Untuk pemakaian pelanggan, upload folder ini ke hosting HTTPS. Setelah pertama kali dibuka online, aplikasi dapat dipakai offline dan data tersimpan di browser perangkat.
