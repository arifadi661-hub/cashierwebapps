# Tutorial instalasi Web App

## Android — Chrome

1. Buka link HTTPS aplikasi di Chrome.
2. Tekan menu tiga titik.
3. Pilih **Install app** atau **Tambahkan ke layar utama**.
4. Tekan **Install**.
5. Buka aplikasi dari ikon Kasir F&B.

## iPhone/iPad — Safari

1. Buka link HTTPS aplikasi di Safari.
2. Tekan tombol **Share/Bagikan**.
3. Pilih **Add to Home Screen/Tambahkan ke Layar Utama**.
4. Tekan **Add/Tambah**.
5. Buka aplikasi dari ikon Kasir F&B.

## Desktop

Buka link HTTPS melalui Chrome atau Edge. Jika tersedia, tekan ikon install di address bar.

## Catatan offline

Buka aplikasi setidaknya sekali saat online agar service worker menyimpan file aplikasi. Setelah itu transaksi utama bisa digunakan offline. Data tersimpan di browser perangkat dan tidak otomatis tersinkron ke perangkat lain.
