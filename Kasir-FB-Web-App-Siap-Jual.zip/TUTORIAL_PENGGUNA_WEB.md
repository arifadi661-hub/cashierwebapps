# Tutorial pengguna Web App

1. Tekan tombol ☰ di kiri atas.
2. Pilih **Kasir**, **Produk**, **Profil**, atau **Laporan**.
3. Di Kasir, cari produk lalu ketuk produk untuk memasukkannya ke keranjang.
4. Tekan **Bayar Sekarang**, pilih metode pembayaran, lalu selesaikan transaksi.
5. Data profil, produk, stok, keranjang, dan transaksi otomatis disimpan di browser.
6. Aplikasi tetap bisa dipakai offline setelah pernah dibuka online.
7. Jangan menghapus data situs/browser sebelum backup karena data lokal bisa ikut hilang.

## Printer thermal

1. Pastikan printer thermal BLE menyala dan sudah diisi kertas.
2. Buka menu **Profil**, lalu tekan **Cari & Hubungkan**.
3. Pilih printer thermal dari daftar Bluetooth browser dan izinkan koneksi.
4. Tekan **Test Print** untuk mengirim cetakan uji.
5. Android Chrome mendukung printer thermal BLE secara langsung. iPhone/iPad memakai AirPrint atau aplikasi bridge printer karena Safari PWA tidak membuka koneksi Bluetooth printer langsung.
